﻿If !A_IsAdmin
  Run *RunAs "%A_ScriptFullPath%"
#NoEnv
#MenuMaskKey vkE8
#SingleInstance Force
DetectHiddenWindows On
SetWorkingDir % A_ScriptDir
If FileExist("HR.ico")
  Menu Tray,Icon,HR.ico
SetTitleMatchMode 2
CoordMode ToolTip
SetBatchLines -1
CoordMode Mouse
CoordMode Pixel
SendMode Input
SnippetsInit()
OnExit EOF
SW:=A_ScreenWidth,SH:=A_ScreenHeight
FormatKeys:={"<^>!u":"{:U}","<^>!l":"{:L}","<^>!t":"{:T}"}
SpVoice:=ComObjCreate("SAPI.SpVoice")

:?*:``e/::é
:?*:``c/::ç
:?*:``o::°
:?*:``|u::µ
:?*:``+-::±
:?*:``//::÷
:?*:``cr::©
:?*:``re::®
:?*:``tm::™
:?*:``cw::▲
:?*:``ca::◄
:?*:``cs::▼
:?*:``cd::►
:?*:``aw::↑
:?*:``aa::←
:?*:``as::↓
:?*:``ad::→
:?*:``.25::¼
:?*:``.5::½
:?*:``.75::¾
:?*:``p2::²
:?*:``p3::³

#Include Keyfile.ahk

<^>!i::                                                    ;Active AHK help if open/run it if not
  If WinExist("AutoHotkey Help")
    WinActivate
  Else
    Run % "C:\Program Files\AutoHotkey\AutoHotkey.chm"
  WinWaitActive AutoHotkey Help
  Send !s
Return
<^>!Space::Winset,Alwaysontop,,A                           ;Toggle active window AlwaysOnTop
<^>!c::Run CQT.ahk                                         ;Run quick code editor
<^>!b::PostMessage 0x111,2143,0,,ahk_class BluetoothNotificationAreaIconWindowClass  ;Show Bluetooch panel
<^>!;::SnippetsShow()                                      ;Show snippets panel
<^>!p::                                                    ;Copy info from currently active window to AppList.txt
  MouseGetPos rX,rY
  WinGetTitle wT,A
  WinGetClass wC,A
  WinGet wE,ProcessName,A
  WinGetPos wX,wY,wW,wH,A
  Clipboard:=wT " ahk_class " wC " ahk_exe " wE "`nM: " rX "," rY "     S: " wX "," wY "," wW "," wH
  SD(Clipboard,3)
  FileAppend % Clipboard "`n`n",AppList.txt
Return
<^>!o::Run AppList.txt                                     ;Open AppList.txt
<^>!m::                                                    ;Copy current mouse info to Clipboard
  CoordMode Mouse,Relative
  MouseGetPos rX,rY
  CoordMode Mouse
  MouseGetPos mX,mY
  PixelGetColor col,mX,mY,RGB
  msg := "A: " mX "," mY "`nR: " rX "," rY "`nC: " SubStr(col,-5)
  SD(msg,02)
  Clipboard:=msg ;SubStr(msg,-5) " " mX "," mY
Return
<^>!t::                                                    ;Title Case selected text
<^>!l::                                                    ;lower case selected text
<^>!u::                                                    ;UPPER CASE selected text
  Clipboard:=""
  Send ^c
  ClipWait
  Clipboard:=% Format(FormatKeys[A_ThisHotkey],Clipboard)
  Send ^v
Return
#c::Run C:\System\VSHelp.ahk                               ;Run VSCode helper
#g::                                                       ;Toggle dimmer
  SD("Dimmer " ((fDim:=!fDim)?"Activated":"Deactivated"),01,10,10)
  DisplaySetBrightness(fDim?96:128)
Return
#If fDim                                                   ;Dimmer brightness controls
  ^End::
    AdjustBrightness(-32)
    SD("Level: " DisplayGetBrightness(),01,10,10)
  Return
  ^Home::
    AdjustBrightness(+32)
    SD("Level: " DisplayGetBrightness(),01,10,10)
  Return
#If

#f::WinMove A,,-8,-4,SW+16,SH+8                            ;Make active window 'fullscreen'
#m::run C:\Windows\System32\perfmon.exe /res               ;Open Windows' performance monitor
#o::                                                       ;Copy info from currently active window to clipboard
  WinGetTitle wT,A
  WinGetClass wC,A
  WinGet wE,ProcessName,A
  WinGetPos wX,wY,wW,wH,% wT
  CoordMode Mouse,Relative
  MouseGetPos rX,rY
  CoordMode Mouse
  MouseGetPos aX,aY
  Clipboard:=wT "`nahk_class " wC "`nahk_exe " wE "`nXYWH: " wX "," wY " " wW "," wH "`nR:" rX "," rY "    A:" aX "," aY
  SD(Clipboard,05)
Return
#;::Run ReIcon\ReIcon_x64.exe /r /ID xyz                   ;Restore saved icon layout
#s::                                                       ;Save current desktop icon layout
  Run ReIcon\ReIcon_x64.exe /s /ID xyz
  SD("Layout saved!",01,,,,18)
Return
#h::                                                       ;Toggle explorer hidden files/folder
  RegRead HiddenFiles_Status,HKEY_CURRENT_USER,Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced,Hidden
  RegWrite REG_DWORD,HKEY_CURRENT_USER,Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced,Hidden,% (HiddenFiles_Status=2)?1:2
  Send {F5}
Return

#t::SpVoice.Speak(Mod(A_Hour+11,12)+1 " " A_Min)           ;Speak the current time
#\::                                                       ;Toggle hourly chime
  SetTimer tChime,% (ChimeOn:=!ChimeOn)?500:"Off"
  SD("Chime " (ChimeOn?"On!":"Off"),0)
Return

#e::                                                       ;Open new explorer window at top left
  Run ::{20d04fe0-3aea-1069-a2d8-08002b30309d}
  WinWaitActive This PC
  WinMove This PC,,0,0,SW/2,SH/2
Return

#Numpad1::Folder("E:\Downloads",3)                         ;Open Downloads folder at bottom left
#Numpad2::Folder("D:\Video",4)                             ;Open Video folder at bottom right
#Numpad3::Folder("C:\Windows\Resources\Themes",2)          ;Open Windows' themes folder at top right
#Numpad4::Folder("D:\Portable\AIMP\Profile\PLS",2)         ;Open AIMP playlist folder at top right
#Numpad5::Folder(A_MyDocuments "\AutoHotkey\Lib",2)        ;Open AHK Lib folder at top right

<^>!Numpad1::WinMove A,,0,SH/2,SW/2,SH/2                   ;Move active window to bottom-left corner
<^>!Numpad2::WinMove A,,0,SH/2,SW,SH/2                     ;Move active window to bottom half
<^>!Numpad3::WinMove A,,SW/2,SH/2,SW/2,SH/2                ;Move active window to bottom-right corner
<^>!Numpad4::WinMove A,,0,0,SW/2,SH                        ;Move active window to left half
<^>!Numpad5::                                              ;Centre active window
  WinGetPos ,,,wgW,wgH,A
  WinMove A,,(SW-wgW)/2,(SH-wgH)/2
Return
<^>!Numpad6::WinMove A,,SW/2,0,SW/2,SH                     ;Move active window to right half
<^>!Numpad7::WinMove A,,0,0,SW/2,SH/2                      ;Move active window to top-left corner
<^>!Numpad8::WinMove A,,0,0,SW,SH/2                        ;Move active window to btop half
<^>!Numpad9::WinMove A,,SW/2,0,SW/2,SH/2                   ;Move active window to top-right corner
<^>!1::WinMove A,,0,0,SW/4,SH                              ;Move active window to 1st quarter slice of screen
<^>!2::WinMove A,,SW/4,0,SW/4,SH                           ;Move active window to 2nd quarter slice of screen
<^>!3::WinMove A,,SW/2,0,SW/4,SH                           ;Move active window to 3rd quarter slice of screen
<^>!4::WinMove A,,SW-SW/4,0,SW/4,SH                        ;Move active window to 4th quarter slice of screen

<^>!Up::                                                   ;Position active window on top half of screen
  WinGetPos wgX,wgY,,,A
  WinMove A,,wgX,wgY-1
Return
<^>!Down::                                                 ;Position active window on bottom half of screen
  WinGetPos wgX,wgY,,,A
  WinMove A,,wgX,wgY+1
Return
<^>!Left::                                                 ;Position active window on left half of screen
  WinGetPos wgX,wgY,,,A
  WinMove A,,wgX-1,wgY
Return
<^>!Right::                                                ;Position active window on right half of screen
  WinGetPos wgX,wgY,,,A
  WinMove A,,wgX+1,wgY
Return

<^>!NumpadDiv::Run nircmd muteappvolume GTA5.exe 2         ;Toggle GTAV's volume off/on

<^>!AppsKey::Edit                                          ;Open this script in the configured editor
AppsKey::                                                  ;Suspend all hotkeys
  Suspend
  SoundPlay % "C:\Windows\Media\Speech " ((fT:=!fT)?"Off.wav":"On.wav")
Return
*Pause::                                                   ;Reload script (after any edits)
  SD("Reloading...",.5)
  Reload
<^>!Pause::ExitApp                                         ;Exit script

tClick:                                                    ;Autoclicker timer code
  Click
Return

tChime:                                                    ;Hourly chime timer code
  If !A_Min && !A_Sec{
    SpVoice.Speak(Mod(A_Hour+11,12)+1 "O'Clock")
  ;  b(A_Hour)
  }
Return

b(v){                                                      ;Beep function for hourly chime
  v:=Mod(v-1,12)+1,q:=Floor(v/3),s:=Mod(v,3)
  Loop % q{
    SoundBeep 440,300
    Sleep 150
  }
  Loop % s{
    SoundBeep 440,100
    Sleep 50
  }
}

Folder(p,l:=1){                                            ;Function to open a folder and position it in a set corner
  w:=A_ScreenWidth,h:=A_ScreenHeight,f:=SubStr(p,InStr(p,"\",,0)+1)
  Run % p
  WinWaitActive % f
  WinMove A,,Mod(l,2)?0:w/2,(l<3)?0:h/2,w/2,h/2
}

ProcSusp(PID_or_Name,Flag:=0){                             ;Suspend/Freeze selected app/game (I use with GTAV)
  PID:=(InStr(PID_or_Name,"."))?ProcExist(PID_or_Name):PID_or_Name
  h:=DllCall("OpenProcess","uInt",0x1F0FFF,"Int",0,"Int",pid)
  If !h
    Return -1
  If Flag
    DllCall("ntdll.dll\NtSuspendProcess","Int",h)
  Else
    DllCall("ntdll.dll\NtResumeProcess","Int",h)
  DllCall("CloseHandle","Int",h)
}

ProcExist(PID_or_Name=""){                                 ;Check if process exists for ProcSusp()
  Process Exist,% (PID_or_Name="")?DllCall("GetCurrentProcessID"):PID_or_Name
  Return Errorlevel
}

SnippetsInit(){                                            ;Snippets initialisation
  Gui Snips:Default
  Gui Font,s15 q5,ProFontWindows
  Gui Color,66CC00
  Gui Margin,3,3
  Gui +AlwaysOnTop +Owner +ToolWindow -Caption +HwndSnippetsHwnd
  Gui Add,ListView,c66CC00 r8 w400,Key|Text
  LV_ModifyCol(1,"Center")
  IniRead,configText,snippets.ini,master    
  Loop Parse,configText,`n,`r
  {
    parts:=StrSplit(A_LoopField,"="," `t")
    LV_Add("",parts[1],parts[2])
  }
}

SnippetsShow(){                                            ;Show snippets window (key press sends relevant line to active window
  Global SnippetsMap
  Gui Snips:Show,NoActivate
  Input key,L1 T3
  Gui Snips:Hide
  If (ErrorLevel!="Timeout"){
    IniRead value,snippets.ini,master,%key%,__SNIPPETS_KEY_NOT_FOUND__
    If (value!="__SNIPPETS_KEY_NOT_FOUND__")
      SendInput %value%
    Else
      MsgBox No snippet found for %key%.
  }
}

AdjustBrightness(V:=0){                                    ;Triggers setting new brightness which also limiting range
  SB:=(SB:=DisplayGetBrightness()+V)>255?255:SB<0?0:SB
  DisplaySetBrightness(SB)
}

DisplaySetBrightness(SB:=128){                             ;Used to set a new brightness setting
  Loop % VarSetCapacity(GB,1536)/6
    NumPut((N:=(SB+128)*(A_Index-1))>65535?65535:N,GB,2*(A_Index-1),"UShort")
  DllCall("RtlMoveMemory","Ptr",&GB+ 512,"Ptr",&GB,"Ptr",512)
  DllCall("RtlMoveMemory","Ptr",&GB+1024,"Ptr",&GB,"Ptr",512)
  Return DllCall("gdi32.dll\SetDeviceGammaRamp","Ptr",hDC:=DllCall("user32.dll\GetDC","Ptr",0),"Ptr",&GB),DllCall("user32.dll\ReleaseDC","Ptr",0,"Ptr",hDC)
}

DisplayGetBrightness(ByRef GB:=""){                        ;Retrieve current brightness setting
  VarSetCapacity(GB,1536,0)
  DllCall("gdi32.dll\GetDeviceGammaRamp","Ptr",hDC:=DllCall("user32.dll\GetDC","Ptr",0),"Ptr",&GB)
  Return NumGet(GB,2,"UShort")-128,DllCall("user32.dll\ReleaseDC","Ptr",0,"Ptr",hDC)
}

EOF:                                                       ;Return brightness on script exit
  DisplaySetBrightness(128)
ExitApp

#w::                                                       ;My custom launcher (connected to 'Data.txt')
  ARR:=[]
  Gui OSDBG:New,+AlwaysOnTop +ToolWindow -Caption
  Gui OSDBG:Color,000000,000000
  Gui OSDBG:Show,% "w" SW " h" SH,OSDBG
  WinSet Transparent,200,OSDBG
  Gui OSDFG:New,+AlwaysOnTop +ToolWindow -Caption
  Gui OSDFG:Font,s72 cLime,Consolas
  Gui OSDFG:Color,040404,040404
  Gui OSDFG:Add,Edit,x-2 y-2 w584 r1 Limit10 Uppercase Center -E0x200 gChanged vAIM ;,1234567890
  Gui OSDFG:Font,s24 cLime,Consolas
  Gui OSDFG:Add,Text,x0 y120 w580 Center vvText,Reading Data
  Gui OSDFG:Show,w580 h170,OSDFG
  Loop Read,C:\System\Data.txt
  {
    c:=A_Index,t:=RegExReplace(A_LoopReadLine,"\t+","|")
    Loop Parse,t,|
      ARR[c,A_Index]:=A_LoopField
  }
  GuiControl OSDFG:,vText
Return

#If WinExist("OSDFG")
LButton::WinActivate OSDFG
MButton::WinActivate OSDFG
RButton::WinActivate OSDFG
Enter::
  Gui OSDFG:Submit
  VSB:=0
  If HIT
    Run % HIT, % SubStr(HIT,1,InStr(HIT,"\",,0,1))
  Else
    MsgBox 48,% "Bugger...",% "Nothing selected.",1.5
  Gui OSDFG:Destroy
  Gui OSDBG:Destroy
Return
~Alt::
Esc::
  Gui OSDFG:Destroy
  Gui OSDBG:Destroy
Return
#If

Changed:
  Gui OSDFG:Submit,NoHide
  Loop % ARR.Count(){
    If (ARR[A_Index,1]=AIM){
      GuiControl OSDFG:,vText,% ARR[A_Index,2]
      HIT:=ARR[A_Index,3]
      Break
    }Else If (AIM=""){
      GuiControl OSDFG:,vText
      HIT:=""
    }Else{
      GuiControl OSDFG:,vText,% "..."
      HIT:=""
    }
  }
Return