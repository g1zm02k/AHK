﻿SW:=A_ScreenWidth,SH:=A_ScreenHeight

F1::
  ARR:=[]

  Gui OSDBG:New,+ToolWindow -Caption
  Gui OSDBG:Color,000000,000000
  Gui OSDBG:Show,% "w" SW " h" SH,OSDBG
  WinSet Transparent,250,OSDBG

  Gui OSDFG:New,+AlwaysOnTop +ToolWindow -Caption
  Gui OSDFG:Font,s72 cLime,Consolas
  Gui OSDFG:Color,080808,080808
  Gui OSDFG:Add,Edit,x-2 y-2 w584 r1 Limit10 Uppercase Center -E0x200 gChanged vAIM
  Gui OSDFG:Font,s24 cLime,Consolas
  Gui OSDFG:Add,Text,x0 y120 w580 Center vvText,Reading Data
  Gui OSDFG:Show,w580 h170,OSDFG

  Loop Read,Data.txt
  {
    c:=A_Index,t:=RegExReplace(A_LoopReadLine,"\t+","|")
    Loop Parse,t,|
      ARR[c,A_Index]:=A_LoopField
  }
  GuiControl OSDFG:,vText
Return

#If WinExist("OSDFG")
LButton::WinActivate OSDFG
MButton::WinActivate OSDFG
RButton::WinActivate OSDFG
Enter::
  Gui OSDFG:Submit
  VSB:=0
  If HIT
    Run % HIT, % SubStr(HIT,1,InStr(HIT,"\",,0,1))
  Else
    MsgBox 48,% "Bugger...",% "Nothing selected.",1.5
  Gui OSDFG:Destroy
  Gui OSDBG:Destroy
Return
Esc::
  Gui OSDFG:Destroy
  Gui OSDBG:Destroy
Return
#If

Changed:
  Gui OSDFG:Submit,NoHide
  Loop % ARR.Count(){
    If (ARR[A_Index,1]=AIM){
      GuiControl OSDFG:,vText,% ARR[A_Index,2]
      HIT:=ARR[A_Index,3]
      Break
    }Else If (AIM=""){
      GuiControl OSDFG:,vText
      HIT:=""
    }Else{
      GuiControl OSDFG:,vText,% "..."
      HIT:=""
    }
  }
Return