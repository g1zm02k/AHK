﻿#If WinActive("Assassin’s Creed® Odyssey ahk_exe ACOdyssey.exe")
  F13::r
  F14::v
  F15::m
  F16::`
  F17::1
  F18::Esc
  F19::2
  F20::3
  F21::4
  XButton1::t
  XButton2::g
#If WinActive("Assassin's Creed Origins ahk_exe ACOrigins.exe")
  F13::r
  F14::v
  F15::m
  F16::4
  F17::e
  F18::Esc
  XButton1::2
  XButton2::3
#If WinActive("Assassin's Creed Valhalla ahk_exe ACValhalla.exe")
  F13::r
  F14::1
  F15::v
  F16::4
  F17::3
  F18::2
  F19::t
  F20::h
  F21::g
  XButton1::m
  XButton2::Esc
#If WinActive("Beyond Good & Evil - Ubisoft ahk_class BGEMain")
  XButton2::e
  XButton1::q
#If WinActive("Beyond: Two Souls ahk_class BeyondTwoSouls")
  XButton2::1
  XButton1::4
  MButton::Tab
  [::LShift
  ]::c
#If WinActive("Call of Cthulhu ahk_class UnrealWindow")
  XButton2 & LButton::e
  XButton2 & RButton::w
  XButton2 & MButton::f
  [::a
  ]::d
  XButton1::Esc
  Numpad0::run D:\Coding\CoC Backup.ahk Copied
  NumpadDot::run D:\Coding\CoC Backup.ahk Deleted
  NumpadEnter::run D:\Coding\CoC Backup.ahk Editing
#If WinActive("ahk_class CoDBlackOps ahk_exe blackops3.exe")
  F13::1
  F14::2
  F15::3
  F16::\
  F17::4
  F18::Esc
#If WinActive("Cue Club 2 ahk_exe cueclub2.exe")
  F14::e
  F17::Space
#If WinActive("Crysis Remastered ahk_exe CrysisRemastered.exe")
  F13::[
  F14::c
  F15::]
  F16::b
  F17::r
  F18::z
  XButton1::m
  XButton2::Esc
  MButton::6
  ^XButton2::Return
#If WinActive("CTRLroom ahk_class UnrealWindow")
  XButton2::q
  XButton1::e
  MButton::Enter
#If WinActive("Cyberpunk 2077 (C) 2020 by CD Projekt RED ahk_class W2ViewportClass")
  XButton2::f
  XButton1::Tab
  ]::Esc
  [::c
#If WinActive("Cyberpunk 2077® on GeForce NOW ahk_class CEFCLIENT")
  XButton2::f
  XButton1::Tab
  ]::Esc
  [::c
#If WinActive("The Darkside Detective ahk_class UnityWndClass")
  Space::LButton
#If WinActive("Death Stranding ahk_class PIGS_MainWnd")
  PGUP::
    SetTimer tDS,% (fDS:=!fDS)?5000:"Off"
  tDS:
    Send {q Down}
    Sleep 100
    Send {q Up}
  Return
#If WinActive("ahk_class DEATHLOOP ahk_exe Deathloop.exe")
  F13::Tab ;Powers
  F14::t   ;Tag
  F15::j   ;Journal
  F16::h   ;Hackamajig
  F17::f   ;Use
  F18::Esc ;Back
  F21::Enter
#If WinActive("Dishonored 2 using VoidEngine v1.77.9.0 ahk_class Dishonored 2")
  \::Esc
  x::0
  [::Esc
#If WinActive("Dishonored: Death of the Outsider using VoidEngine v1.145.0.0 ahk_class Dishonored: Death of the Outsider")
  \::Esc
  x::0
  [::Esc
#If WinActive("Fallout4 ahk_class Fallout4")
  XButton2::e
#If WinActive("FarCry®5 ahk_class Nomad")
  Control::c
  c::Control
#If WinActive("ahk_class fox")
  XButton1::o
  XButton2::p
#If WinActive("Ghost Recon® Breakpoint")
  F13::c
  F14::x
  F15::b
  F16::z
  F17::v
  F18::g
  XButton1::m
  XButton2::Esc
#If WinActive("Ghost Recon® Wildlands ahk_exe GRW.exe")
  F13::c
  F14::z
  F15::b
  F16::4
  F17::n
  F18::g
  XButton1::m
  XButton2::Esc
#If WinActive("Ghostwire: Tokyo ahk_exe GWT.exe")
  F13::Tab      ;Spectral Vision
  F14::q        ;Block
  F15::MButton  ;Melee
  F16::v        ;Super Wire
  F17::e        ;Swap Powers
  F18::r        ;Recurve Bow
  XButton1::m   ;Map
  XButton2::Esc ;Back
  F19::1
  F20::2
  F21::3
  F22::5
  F23::7
  F24::8
#If WinActive("Grand Theft Auto V ahk_class grcWindow")
  XButton2::n
  XButton1::g
#If WinActive("Halo: Spartan Strike ahk_class BLUE_WINDOWCLASS")
  XButton2::1
  XButton1::2
#If WinActive("Hellpoint ahk_class UnityWndClass ahk_exe Hellpoint.exe")
  XButton2::LCtrl
  XButton1::v
  [::Esc
  ]::Enter
  !e::Return
  Ins::ControlSend ahk_parent,+^{Tab},ahk_exe Firefox.exe
  Del::ControlSend ahk_parent,^{Tab},ahk_exe Firefox.exe
  Home::ControlSend ahk_parent,{Up},ahk_exe Firefox.exe
  End::ControlSend ahk_parent,{Down},ahk_exe Firefox.exe
  PgDn::ControlSend ahk_parent,{PgDn},ahk_exe Firefox.exe
  PgUp::ControlSend ahk_parent,{PgUp},ahk_exe Firefox.exe
#If WinActive("Immortals Fenyx Rising™ ahk_exe ImmortalsFenyxRising.exe")
  F13::c
  F14::1
  F15::r
  F16::4
  F17::3
  F18::2
  XButton1::Tab
  XButton2::Esc
#If WinActive("Inscryption ahk_exe Inscryption.exe")
  F13::q
  F14::w
  F15::e
  F16::a
  F17::s
  F18::d
  XButton1::a
  XButton2::d
  ;Shift+a+s
#If WinActive("Just Cause 3 ahk_class JC3")
  XButton2::LShift
  XButton1::LCtrl
  j::z
  l::c
  i::w
  k::s
#If WinActive("Just Cause 4 ahk_class JC4")
  ;XButton2::v
  Xbutton1::1
  [::z
  ]::c
#If WinActive("Kingdoms of Amalur: Reckoning ahk_class BigHugeClass")
  XButton2::c
  XButton1::m
  MButton::Esc
#If WinActive("Mad Max ahk_class Mad Max")
  XButton1::f
  XButton2::Space
  B::
    Send {c down}{x down}
    Sleep 300
    Send {x up}{c up}
  Return
#If WinActive("Mass Effect™: Andromeda ahk_class Mass Effect™: Andromeda")
  XButton2::Esc
  XButton1::LCtrl
#If WinActive("Mini Motorways ahk_exe Mini Motorways.exe")
  MButton::Space
#If WinActive("Moons of Madness ahk_class UnrealWindow")
  XButton2::f
  XButton1::o
  r::t
  e::MouseClick Left
  q::MouseClick Right
#If WinActive("No Man's Sky ahk_class GLFW30")
  XButton2::f
  XButton1::g
  [::q
  ]::e
#If WinActive("Observation ahk_class UnityWndClass")
  XButton2::c
  XButton1::z
  x::BackSpace
  MButton::Tab
  [::o
  ]::r
#If WinActive("Outer Wilds ahk_exe OuterWilds.exe")
  F13::e
  F14::Up
  F15::r
  F16::Left
  F17::Down
  F18::Right
  XButton1::y
  XButton2::f
  ~LButton::e
  MButton::c
#If WinActive("Oxenfree ahk_class UnityWndClass")
  XButton1::Space
  XButton2::LShift
  MButton::LCtrl
  Up::w
  Down::s
  Left::a
  Right::d
#If WinActive("ParadiseKiller ahk_class UnrealWindow")
  XButton2::e
  XButton1::q
  [::Tab
  ]::Esc
#If WinActive("Pool Nation FX ahk_class UnrealWindow")
  XButton2::Space
  XButton1::O
  w::s
  s::w
#If WinActive("Project Dreamland 1.0 ahk_class Area 51 Window")
  XButton2::F
  XButton1::V
#If WinActive("ahk_class RememberMeUnrealUWindowsClient")
  f::Enter
  q::Tab
  XButton2::e
  XButton1::v
  r::MButton
  c::MButton
#If WinActive("République ahk_class UnityWndClass")
  XButton2::Escape
#If WinActive("RESIDENT EVIL 7 biohazard ahk_class via")
  F13::Tab
  F14::f
  F15::m
  F16::Numpad0
  F17::x
  F18::Esc
#If WinActive("Saints Row: Gat out of Hell ahk_class sr_hv")
  XButton2::Tab
  XButton1::Escape
#If WinActive("Saints Row: The Third ahk_class SR3")
  XButton2::Tab
  XButton1::Escape
#If WinActive("Saints Row IV ahk_class SRE4")
  XButton2::Tab
  XButton1::Escape
#If WinActive("SatelliteReign ahk_class UnityWndClass")
  `::^a
  XButton2::,
  XButton1::.
#If WinActive("Shadow Warrior")
  z::8
#If WinActive("Sherlock Holmes: The Devil's Daughter ahk_class LaunchUnrealUWindowsClient")
  XButton2::t
  XButton1::Escape
#If WinActive("Skyrim Special Edition ahk_class Skyrim Special Edition")
  XButton2::m
  XButton1::`
#If WinActive("Snooker Nation ahk_class UnrealWindow")
  XButton2::Space
  XButton1::o
#If WinActive("The Solitaire Conspiracy ahk_class UnityWndClass")
  XButton2::MouseClick L,1767,984,,0 ;Skip
  MButton::MouseClick L,1686,880,,0 ;Continue/Restart
#If WinActive("Star Trek ahk_class StarTrekPCEvolutionGfxD3D")
  XButton2::c
  XButton1::e
#If WinActive("STAR WARS Jedi: Fallen Order ahk_class UnrealWindow")
  F13::2
  F14::z
  F15::m
  F16::3
  F17::1
  F18::Esc
  XButton1::b
  XButton2::n
#If WinActive("Starbound ahk_class SDL_app")
  XButton2::f
  XButton1::Esc
#If WinActive("T42 ahk_class UnityWndClass")
  XButton1::e
  XButton2::q
#If WinActive("Teardown ahk_exe teardown.exe")
  F13::1
  F14::2
  F15::3
  F16::4
  F17::5
  F18::6
#If WinActive("The Turing Test ahk_class UnrealWindow")
  XButton2::BackSpace
  XButton1::e
#If WinActive("Titanfall 2 ahk_exe Titanfall2.exe")
  F13::Ctrl
  F14::e
  F15::x
  F16::g
  F17::q
  F18::c
  XButton2::Esc
#If WinActive("Valley ahk_class UnityWndClass")
  XButton2::e
  $WheelUp::ControlClick ,,ahk_exe Notepad.exe,,WheelUp
  $WheelDown::ControlClick ,,ahk_exe Notepad.exe,,WheelDown
#If WinActive("Watch_Dogs")
  XButton2::q
  XButton1::Esc
#If WinActive("Watch_Dogs 2")
  XButton1::Esc
#If WinActive("Watch Dogs Legion ahk_class NomadWD2")
  F13::v
  F14::q
  F15::f
  F16::3
  F17::4
  F18::5
  XButton1::m
  XButton2::Esc
  ^XButton2::Return

;                        ||///////\\\\\\\||

#If WinActive("CodeQuickTester - Find ahk_class AutoHotkeyGUI")  ;For use with CQT.ahk's Find window
  F1::                                                     ;Replace Tabs with Spaces
    Send \t{Tab 3}  {Tab 4}{Space}
    Click 1422 716
    KeyWait F1
    Click 1336 794
    Click 1448 662
  Return
  F2::                                                     ;Remove all comments after code
    Send {Space}{+}{;}.*{Tab 7}{Space}
    Click 1422 716
    KeyWait F2
    Click 1336 794
    Click 1448 662
  Return
#If WinActive("CodeQuickTester ahk_class AutoHotkeyGUI")  ;For use with CQT.ahk
  F6::                                                    ;Prefix 4 spaces for posting via Reddit markdown mode
    Clipboard:=""
    Send ^c
    ClipWait 0
    Clipboard:=% RegExReplace(Clipboard,"`am)^(.*)","    $1")
    SD("Copied!",0)
  Return
  F7::                                                     ;Add comment blocks to selected code
    Clipboard:=""
    Send ^c
    ClipWait 0
    TXT:=LNG:=""
    Loop Parse,Clipboard,`n,`r
      LNG.=SubStr("0000" StrLen(A_LoopField),-4) "`n"
    Sort LNG,R
    LNG:=SubStr(LNG,1,5)+0
    StringReplace TMP,Clipboard,`n,,UseErrorLevel
    MAX:=ErrorLevel+1
    For CTR,STR in StrSplit(Clipboard,"`n","`r")
      If !((CTR=MAX) && !StrLen(STR))
        TXT.=STR.=Format("{: " LNG-StrLen(STR)+3 "}",";") "`n"
    Clipboard:=TXT
    Send ^v
  Return
  <^>!e::                                                  ;SetTimer quick snippet
    Clipboard:="F1::SetTimer tT,% (fT:=!fT)?50:""Off""`n`ntT:`n  Send {Space}`nReturn"
    Send ^v
  Return
  <^>!r::                                                  ;SetTimer bigger snippet
    Send ^{Home}
    Sleep 200
    Clipboard:="#Persistent`nCoordMode ToolTip`nSetTimer tX,50`n`n"
    Send ^v
    Sleep 200
    Send ^{End}
    Clipboard:="`n`ntX:`n  l:=GetKeyState(""LAlt"")`n  p:=GetKeyState(""LAlt"",""P"")`n  "
    Clipboard.="nT:=""L: "" l ""``nP: "" p`n  If (nT!=oT)`n    ToolTip % nT,0,A_ScreenHeight`n  oT:=nT`nReturn"
    Send ^v
  Return
#If WinActive("ahk_exe Notepad.exe") || WinActive("ahk_exe Notepad++.exe")
  ^F1::                                                    ;Prefix 4 spaces for posting via Reddit markdown mode
    Clipboard:=""
    Send ^c
    ClipWait
    Clipboard:=% RegExReplace(Clipboard,"`am)^(.*)","    $1")
    Send ^v
  Return
#If WinActive("ahk_class illustrator")
  XButton1::[
  XButton2::]
  MButton::x
  F13::Ctrl
  F14::Space
  F15::
    Send {Ctrl Down}{Space Down}
    KeyWait F15
    Send {Space Up}{Ctrl Up}
  Return
#If WinActive("ahk_class Photoshop")
  XButton1::[
  XButton2::]
  MButton::x
  F13::Ctrl
  F14::Space
  F15::
    Send {Ctrl Down}{Space Down}
    KeyWait F15
    Send {Space Up}{Ctrl Up}
  Return
#If WinActive("Playlist ahk_exe PotPlayerMini64.exe")
  XButton2::
    WinGetPos wX,wY,wW,wH,ahk_class PotPlayer64 ahk_exe PotPlayerMini64.exe
    If (wX-304>0)
      WinMove Playlist ahk_exe PotPlayerMini64.exe,,wX-304,wY,304,wH
    Else
      WinMove Playlist ahk_exe PotPlayerMini64.exe,,A_ScreenWidth/2-153,A_ScreenHeight/2-270,306,540
  Return
  XButton1::WinMove Playlist ahk_exe PotPlayerMini64.exe,,A_ScreenWidth/2-153,A_ScreenHeight/2-270,306,540
#If WinActive("ahk_class PotPlayer64 ahk_exe PotPlayerMini64.exe")
  F14 & WheelUp::WinMove ahk_class PotPlayer64 ahk_exe PotPlayerMini64.exe,,SW/2,0,SW/2,SH/2
  F14 & WheelDown::WinMove ahk_class PotPlayer64 ahk_exe PotPlayerMini64.exe,,2120,360,440,360
  F13::Send {x 5}
  F14::Return
  F15::Send {c 5}
  F16::x
  F17::z
  F18::c
#If WinActive("ahk_exe Firefox.exe")
  F13::PgDn
  F14::
    Send {Ctrl Down}
    KeyWait F14
  Return
  *F14 Up:: Send {Ctrl Up}
  F15::PgUp
  F16::
  F17::
  F18::
    Send {F6}
    RedCheck:=0
    Sleep 200
    Clipboard:=""
    Send ^c
    ClipWait 0
    If (A_ThisHotkey="F16") && InStr(Clipboard,"www.reddit.com")
        Clipboard:=StrReplace(Clipboard,"www.reddit.com","old.reddit.com"),RedCheck:=1
    Else If (A_ThisHotkey="F17") && InStr(Clipboard,"reddit.com")
      Clipboard:=StrReplace(Clipboard,"reddit.com","reveddit.com"),RedCheck:=1
    Else If (A_ThisHotkey="F17") && InStr(Clipboard,"reveddit.com")
      Clipboard:=StrReplace(Clipboard,"reveddit.com/v","reddit.com/r"),RedCheck:=1
    Else If (A_ThisHotkey="F18") && InStr(Clipboard,"old.reddit.com")
      Clipboard:=StrReplace(Clipboard,"old.reddit.com","www.reddit.com"),RedCheck:=1
    If RedCheck
      Send ^v{Enter}
  Return
#If