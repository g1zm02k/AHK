﻿#NoEnv
#MenuMaskKey vkE8
#SingleInstance Force
SetWorkingDir %A_ScriptDir%
If FileExist("VS.ico")
  Menu Tray,Icon,VS.ico
CoordMode ToolTip
SetBatchLines -1
SetWinDelay 0
CoordMode Mouse
CoordMode Pixel
SetTimer VST,1
SetTimer VSC,250
HLP:=[]
WinGet wID,ID,ahk_exe Code.exe

Gui H:New,+Owner%wID% +AlwaysOnTop +ToolWindow -Caption +E0x20       ;Status bar
Gui Font,s9 cWhite,ProFontWindows
Gui Color,007ACC
Gui Add,Text,x10 y0 w940 h14 vINF,Info...
Gui Show,NoActivate x1280 y703 h14 w1020,H ;x960 y523 w760 h14,H

Gui M:New,+Owner%wID% +AlwaysOnTop +ToolWindow -Caption +E0x20       ;Popup info
Gui Font,s9 cWhite,ProFontWindows
Gui Color,007ACC
Gui Add,Text,x5 y5 w834 h142 vDTL,Details...

Loop Read,AHKH.txt
{
  c++
  Loop Parse,A_LoopReadLine,@
    HLP[c,A_Index]:=RegExReplace(A_LoopField,"``","`n`n")
}
Return

#Esc::ExitApp 
#If WinActive("ahk_class Chrome_WidgetWin_1 ahk_exe Code.exe")
^!Space::
^Space::
!Space::
  Clipboard=
  Send {Left 2}^{Right}^+{Left}^c
  ClipWait
  CLP:=Clipboard
  Clipboard=
  Send +{Left}^c
  ClipWait
  If (Clipboard="#" CLP)
    CLP:=Clipboard
  Else If (Clipboard="_" CLP){
    Send +{Left}^c
    ClipWait
    CLP:=Clipboard
  }
  Send {Right}
  Loop % HLP.Count(){
    If InStr(SubStr(HLP[A_Index,1],1,StrLen(CLP)),CLP){
      If (A_ThisHotkey="!Space"){
        If WinExist("AutoHotkey Help")
          WinActivate
        Else
          Run C:\Program Files\AutoHotkey\AutoHotkey.chm
        WinWaitActive AutoHotkey Help
        Send !s
        Clipboard:=CLP
        SendInput ^a^v{Enter}
      }Else If (A_ThisHotkey="^Space")
        GuiControl H:,INF,% HLP[A_Index,2]
      Else{
        GuiControl M:,DTL,% HLP[A_Index,2] "`n`n" HLP[A_Index,3]     ;Details!
        mX:=cX+102+((cW-960)/2),mY:=cY+cH-((cX=-8)?174:164),mW:=844,mH:=142
        Gui M:Show,NoActivate x%mX% y%mY% w%mW% h%mH%,M
        Sleep 1000
        KeyWait Ctrl,D
        Gui M:Hide
      }
      Break
    }
  }
Return
#If

VST:
  cA:=% (WinActive("ahk_exe Code.exe") && !WinActive("ahk_class #32770"))?1:0
  If cA{
    WinGetPos cX,cY,cW,cH,ahk_exe Code.exe
    If (cX!=oX || cY!=oY || cW!=oW || cH!=oH){
      Gui M:Hide
      If (cX=-8)
        WinMove H,,0,A_ScreenHeight-18,A_ScreenWidth-200
      Else
        WinMove H,,cX,cY+cH-17,cW-260       ;<- Info Bar Width!
    }
    Gui H:Show,NoActivate
  }Else{
    Gui H:Hide
  }
  oA:=cA,oX:=cX,oY:=cY,oW:=cW,oH:=cH
Return

VSC:
  If cA{
    PixelGetColor cP,cX+cW-((cX=-8)?22:14),cY+cH-((cX=-8)?22:14),RGB Fast
    PixelGetColor cO,cX+((cX=-8)?12:4),cY+cH-((cX=-8)?28:20),RGB Fast
    PixelGetColor cT,cX+cW-((cX=-8)?30:22),cY+cH-((cX=-8)?14:6),RGB Fast
    If (cP!=oP && cP=cO){
      Gui H:Color,% cP
      Gui M:Color,% cP
      GuiControl H:+c%cT%,INF
      GuiControl M:+c%cT%,DTL
      WinSet TransColor,% cP,H
      oP:=cP
    }
  }
Return