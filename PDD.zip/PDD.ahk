﻿#SingleInstance Force
SetWorkingDir %A_ScriptDir%
SetTitleMatchMode 2
CoordMode Mouse
CoordMode Pixel

wT:="Footage"  ;Selection Window Title
cF:="0x3C3C3C" ;Selection FG
sF:="0x4D4D4D" ;Scrollbar FG
sB:="0x171717" ;Scrollbar BG
bL:=210        ;Nav-panel Width
bT:=110        ;Toolbar Height
bR:=340        ;Right Info Width
bB:=25         ;Status Bar Height
Global cX,cY,cW,cH

WinGetPos cX,cY,cW,cH,% wT " ahk_exe explorer.exe"
Gui OSD:New,+AlwaysOnTop +ToolWindow -Caption +E0x20
Gui Font,s18 cLime,Consolas
Gui Color,000000
Gui Add,Text,x4 y0 w600 h32 vMSG,% "Press NP0 to start the first test."
Gui Show,NoActivate x%cX% y%cY% w%cW% h30,OSD
WinSet Transparent,200,OSD

Numpad0:: ;### Find Selection Area ###
  OSD("Detect Selection Area...")
  Sleep 999
  WinActivate % wT " ahk_exe explorer.exe"
  WinGetPos cX,cY,cW,cH,% wT " ahk_exe explorer.exe"
  w1x:=cX+bL,w1y:=cY+bT,w1w:=cW-bR-bL,w1h:=cH-bB-bT
  Gui w1:New,+AlwaysOnTop +ToolWindow -Caption +E0x20
  Gui Color,80ff00
  Gui Show,NoActivate x%w1x% y%w1y% w%w1w% h%w1h%,w1
  WinSet Transparent,25,w1
  Sleep 1000
  Gui w1:Destroy
  OSD("If that's fine, press NP1.")
Return

Numpad1:: ;### Find Scrollbar's Top/Bottom ###
  OSD("Detect Scrollbar Limits...")
  Sleep 999
  WinActivate % wT " ahk_exe explorer.exe"
  WinGetPos cX,cY,cW,cH,% wT " ahk_exe explorer.exe"
  w1x:=cX+bL,w1y:=cY+bT,w1w:=cW-bR-bL,w1h:=cH-bB-bT
  MouseMove w1x+w1w+20,w1y+5
  Sleep 500
  MouseMove w1x+w1w+20,w1y+w1h-20
  Sleep 500
  MouseMove w1x+w1w+20,w1y+5
  Sleep 500
  MouseMove w1x+w1w+20,w1y+w1h-20
  OSD("If that's fine, press NP2.")
Return

Numpad2:: ;### Window Scroll Test ###
  OSD("Testing window scroll...")
  Sleep 999
  WinActivate % wT " ahk_exe explorer.exe"
  WinGetPos cX,cY,cW,cH, % wT " ahk_exe explorer.exe"
  w1x:=cX+bL,w1y:=cY+bT,w1w:=cW-bR-bL,w1h:=cH-bB-bT
  MouseMove w1x+50,w1y+50
  OSD("Scroll up test...")
  Sleep 999
  Loop{
    PixelGetColor pC,w1x+w1w+20,w1y+5,RGB
    If (pC!=sB)
      Break
    Send {WheelUp}
  }
  OSD("Scroll down test...")
  Sleep 999
  Loop{
    PixelGetColor pC,w1x+w1w+20,w1y+w1h-20,RGB
    If (pC=sF)
      Break
    Send {WheelDown}
  }
  OSD("If that's fine, select a file and press NP3.")
Return

Numpad3:: ;### Find Selection Test ###
  OSD("Trying to find selected file...")
  Sleep 999
  WinActivate % wT " ahk_exe explorer.exe"
  WinGetPos cX,cY,cW,cH, % wT " ahk_exe explorer.exe"
  w1x:=cX+bL,w1y:=cY+bT,w1w:=cW-bR-bL,w1h:=cH-bB-bT,fF:=0
  MouseMove w1x+50,w1y+50
  Loop{
    PixelGetColor pC,w1x+w1w+20,w1y+5,RGB
    If (pC!=sB)
      Break
    Send {WheelUp}
  }
  Loop{
    PixelSearch pX,pY,w1x,w1y,w1x+w1w,w1y+w1h,% cF,,RGB Fast
    If !ErrorLevel{
      fF:=1
      Break
    }Else{
      PixelGetColor pC,w1x+w1w+20,w1y+w1h-20,RGB
      If (pC=sF)
        Break
      Send {WheelDown}
    }
  }
  PixelSearch pX,pY,w1x,w1y,w1x+w1w,w1y+w1h,% cF,,RGB Fast
  If fF{
    OSD("Found at " pX "," pY "!") 
    MouseMove pX+2,pY
		Sleep 999
		OSD("Also try NP4!")
  }Else
    OSD("Nothing found; try NP4 instead!")
Return

Numpad4:: ;### Alt. Selection Test ###
  OSD("Trying to find selected file...")
  Sleep 999
  WinActivate % wT " ahk_exe explorer.exe"
  WinGetPos cX,cY,cW,cH, % wT " ahk_exe explorer.exe"
  w1x:=cX+bL,w1y:=cY+bT,w1w:=cW-bR-bL,w1h:=cH-bB-bT,fF:=0
  MouseMove w1x+50,w1y+50
  Loop{
    PixelGetColor pC,w1x+w1w+20,w1y+20,RGB
    If (pC!=sB)
      Break
    Send {WheelUp}
  }
  Loop{
    ImageSearch pX,pY,w1x,w1y,w1x+w1w,w1y+w1h,% "*5 PDD.png"
    If !ErrorLevel{
      fF:=1
      Break
    }Else If (ErrorLevel=1){
      PixelGetColor pC,w1x+w1w+20,w1y+w1h-20,RGB
      If (pC=sF)
        Break
      Send {WheelDown}
    }Else
			MsgBox % "Make sure the ""PDD.png"" file is in the same directory as the script!"
  }
  ImageSearch pX,pY,w1x,w1y,w1x+w1w,w1y+w1h,% "*5 PDD.png"
  If fF{
    OSD("Found at " pX "," pY "!") 
    MouseMove pX+2,pY
  }Else
    OSD("Nothing found!")
	Sleep 999
	OSD("Report back!")
Return

Esc::
  Gui OSD:Destroy
ExitApp

OSD(TXT:=""){
  Gui OSD:Show,NoActivate
  GuiControl OSD:,MSG,% TXT
  SetTimer tT,-2000
}

tT:
  Gui OSD:Hide
Return